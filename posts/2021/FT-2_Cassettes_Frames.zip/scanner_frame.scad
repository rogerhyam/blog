

// lower box

outer_width = 60;
outer_y = 150;
out_z = 5 ;


centre_line_x = outer_width/2;
centre_line_y = outer_y/2;

film_width = 36;

film_gate_x = 25;
film_gate_y = 110;

plate_x = 104.5;
plate_y = 163;
plate_z = 3;

plate_center_x = plate_x/2;
plate_center_y = plate_y/2;

plate_hole_x = 40;
plate_hole_y = 130;


// uncomment the bits you want to render.

//base();
//lid();

translate([
    -1 * ((plate_x - outer_width)/2),
    -1 * ((plate_y - outer_y)/2),
    -2
])
plate();

module plate(){
    difference(){
        
        difference(){
            
            union(){
                
                // the plate
                cube([plate_x, plate_y, plate_z]);

                // the ridge
                translate([
                    (plate_x - 70)/2,
                    (plate_y - 160)/2,
                    3
                ])
                cube([70, 160, 2]); 
                
            }
        
            // hole for neg holder
                        // the ridge
            translate([
                (plate_x - 62)/2,
                (plate_y - 152)/2,
                2
            ])
            cube([62, 152, 30]); 
            
        }
        
        // plate hole
        translate([
            (plate_x - plate_hole_x)/2,
            (plate_y - plate_hole_y)/2,
            -5
            ])
            cube([plate_hole_x, plate_hole_y, 30]);
    }

}


module lid(){

difference(){
    
    union(){
        
        // film slot
        translate([
                centre_line_x - (film_width/2) +0.5,
                0,
                3.1])
            cube([
                film_width -1,
                outer_y,
                out_z - 3.1 +5]
            );
            
        // lid
        translate([0,0,out_z])
            cube([60,150,5]);
    }
    
    // film gate
    
    hull(){
        translate([ 
           centre_line_x - (film_gate_x/2),
           centre_line_y - (film_gate_y/2),
           3])
           cube([film_gate_x,film_gate_y,2]);
        
        slope = 1.3;
        translate([ 
           centre_line_x - (film_gate_x * slope/2),
           centre_line_y - (film_gate_y * slope/2),
           out_z + 5])
           cube([film_gate_x * slope,film_gate_y * slope,2]);
    }
    
}

}
            

module base(){
    
    difference(){
        // outer shape
        cube([60,150,out_z]);

        // film slot
        translate([ centre_line_x - (film_width/2), -5, 3.1])
            cube([film_width,outer_y + 10,40]);
        
        // film gate
         translate([ 
            centre_line_x - (film_gate_x/2),
            centre_line_y - (film_gate_y/2),
            -5])
            cube([film_gate_x,film_gate_y,40]);
    
    }
    
}

