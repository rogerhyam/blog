#!/usr/bin/php -q
<?php

// useful vars

$fileLimit = -1; # number of files processed each time script is run. Use -1 for no limit

$doCropping = false; # Change this to true if you want to crop the images BEFORE ROTATION
$cropX = 100; // pixels from left crop rectangle starts
$cropY = 100; // pixels from top crop rectangle will start
$cropWidth = 3750; // width of crop rectangle
$cropHeight = 2350; // height of crop rectangle

if ($handle = opendir('src')) { 
 
 $rotation = 90;
 
 $fileCount = 0;
 while(false!== ($file = readdir($handle))) { 

   // ignore directories
   if ($file == '.' && $file == '..') continue;

   // only look to jpgs
   if (!preg_match("'\.JPG$'", $file)) continue;

   // tell the world we will process this file
   echo "Processing $file ... \n";

   // Load the image
   $source = imagecreatefromjpeg('src/' . $file);

   // do we need to crop the image?
   if ($doCropping){
       
       // do cropping
       echo "   - Cropping image.\n";
       
       $cropped = imagecreatetruecolor($cropWidth, $cropHeight);
       imagecopyresampled($cropped, $source, 0, 0,$cropX, $cropY, $cropWidth, $cropHeight, $cropWidth, $cropHeight);
       
       // the cropped is now the source and ready for rotation
       $source = $cropped;
   }

   // Rotate the correct amount
   echo "   - Rotating $rotation degrees.\n";
   $rotated = imagerotate($source, $rotation, 0);

   // set up for the next one to be rotated the other way
   if ($rotation == 90){
       $rotation = 270;
   }else{
       $rotation = 90;
   }
   
   // write the image out
   $outPath = 'book/' . $file;
   echo "   - Writing image to $outPath.\n";
   imagejpeg($rotated, $outPath);
   
   // keep track of how many images we have processed
   $fileCount++;
   if($fileLimit != -1 && $fileCount >= $fileLimit){
       echo "Hit file limit of $fileLimit so stopping.\n";
       break;
   }

 } 
 closedir($handle);  
}

?>