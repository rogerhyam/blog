#!/usr/bin/php
<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    date_default_timezone_set('UTC');
    
    // lets work through the months
    $baseUri = "http://oai.datacite.org/oai?verb=ListRecords&metadataPrefix=oai_dc";
    

    // work through the months going backwards 5 years
    $year = 2011;
    $thisYear = (int)date('Y');
    while(true){
    
        for($month = 1; $month < 13; $month++){
            
            $monthString = str_pad($month, 2, '0', STR_PAD_LEFT);
            
            switch($month){
                
                case 2:
                    if (date('L', strtotime("$year-01-01"))){
                        $lastDay = 29;
                    }else{
                        $lastDay = 28;
                    }
                    break;
                
                case 4:
                case 6:
                case 9:
                case 11:
                    $lastDay = 30;
                    break;
                
                default:
                    $lastDay = 31;
            }
            
            $fileContent = file_get_contents("$baseUri&from=$year-$monthString-01&until=$year-$monthString-$lastDay");
            
            $matches = array();
            preg_match('/completeListSize="([0-9]+)"/', $fileContent ,$matches);
            
            if(count($matches) >1){
                $count = $matches[1];
            }else{
                $count = 0;
            }
            
            echo "$year-$monthString-01\t$year-$monthString-$lastDay\t$count\n";
            
        }
        
        $year++;
        if($year > $thisYear) break;
    }
    

?>