from microbit import *
import time

# this holds the last n measurements taken
measures = [];

def welcomeMessage():
    display.scroll("SB")
            
def timeExpo():
    global measures
    display.show(Image.ALL_CLOCKS, 150, wait=False, loop=True)
    inExposure = False
    
    # This we count the exposure in microseconds 
    expoStart = 0
    
    # because LED light sources strobe on and off we need to 
    # have a duration of darkness to consider an exposure ended
    # this 
    darkStart = 0
    minDarkDuration = 500

    while True:
        if (pin1.read_analog() > 10): 
            # have we started or are in an exposure
            darkStart = 0
            if(inExposure == False):
                inExposure = True
                expoStart = time.ticks_us()
        else:
            # it has gone dark
            if(darkStart == 0):
                # let's see how long it stays dark before 
                # we assume the exposure if over
                darkStart = time.ticks_us()
                continue
       
            # how long has it been dark
            darkDuration = time.ticks_diff(time.ticks_us(), darkStart)
            if(darkDuration < minDarkDuration):
                # not been dark long enough yet 
                continue
            
            # OK it's been dark for a while were we previously in and exposure?
            if(inExposure):
                inExposure = False
                expoDuration = time.ticks_diff(time.ticks_us(), expoStart) - darkDuration 
                measures.append(expoDuration)
                display.scroll(microSecondsToPhoto(expoDuration), wait=True)
                display.show(Image.ALL_CLOCKS, 150, wait=False, loop=True)

        if button_a.was_pressed():
            displayStats()
            display.show(Image.ALL_CLOCKS, 150, wait=False, loop=True)
        elif button_b.was_pressed():
            clearMemory()
            display.show(Image.ALL_CLOCKS, 150, wait=False, loop=True)
        
def clearMemory():
    global measures
    measures = []
    display.show([Image.TARGET, Image.invert(Image.TARGET), Image.TARGET], 800, wait=True, loop=False)


def displayStats():
    
    if (len(measures) < 1):
        display.scroll("No measurements")
        return
    
    display.scroll(microSecondsToPhoto(sum(measures)/ len(measures)))
    
    display.scroll("n:" + str(len(measures)))
    sleep(1000)
    
    avgSeconds = round((sum(measures)/ len(measures))/1000000, 5)
    display.scroll("avg:" + str(avgSeconds))
    sleep(1000)
    
    maxSeconds = round(max(measures)/1000000, 5)
    display.scroll("max:" + str(maxSeconds))
    sleep(1000)
    
    minSeconds = round(min(measures)/1000000, 5)
    display.scroll("min:" + str(minSeconds))
    sleep(1000)
    
    
    #display.scroll("min: 0.322")
    #sleep(2000)

        
def microSecondsToPhoto(ms):
    
    # we just to this as a big "switch" statement
    # there are few enough cases and exceptions.
    
    # Oveif msr 3 seconds we return B for bulb mode 
    if ms > (3000000 * 1.1): return "B"
    if ms > (3000000 * 0.9): return "3s"
    if ms > 2500000: return "3s-"
    if ms > (2000000 * 1.1): return "2s+"
    if ms > (2000000 * 0.9): return "2s"
    if ms > 1500000: return "2s-"
    if ms > (1000000 * 1.1): return "1s+"
    if ms > (1000000 * 0.9): return "1s"
    if ms > (500000 * 1.1): return "1/2+"
    if ms > (500000 * 0.9): return "1/2"
    if ms > 375000: return "1/2-"
    if ms > (250000 * 1.1): return "1/4+"
    if ms > (250000 * 0.9): return "1/4"
    if ms > 188000: return "1/4-"
    if ms > (125000 * 1.1): return "1/8+"
    if ms > (125000 * 0.9): return "1/8"
    if ms > 700000: return "1/8-"
    if ms > (66666 * 1.1): return "1/15+"
    if ms > (66666 * 0.9): return "1/15"
    if ms > 50000: return "1/15-"
    if ms > (33333 * 1.1): return "1/30+"
    if ms > (33333 * 0.9): return "1/30"
    if ms > 25000: return "1/30-"
    if ms > (16666 * 1.1): return "1/60+"
    if ms > (16666 * 0.9): return "1/60"
    if ms > 12000: return "1/60-"
    if ms > (8000 * 1.1): return "1/125+"
    if ms > (8000 * 0.9): return "1/125"
    if ms > 6000: return "1/125-"
    if ms > (4000 * 1.1): return "1/250+"
    if ms > (4000 * 0.9): return "1/250"
    if ms > 3000: return "1/250-"
    if ms > (2000 * 1.1): return "1/500+"
    if ms > (2000 * 0.9): return "1/500"
    if ms > 1500: return "1/500-"
    if ms > (1000 * 1.1): return "1/1000+"
    if ms > (1000 * 0.9): return "1/1000"
    return "F"
        
# Kick it off
welcomeMessage()
timeExpo()





    
    